
function OnFinish(selProj, selObj)
{
	try
	{
		var strProjectPath = wizard.FindSymbol('PROJECT_PATH');
		var strProjectName = wizard.FindSymbol('PROJECT_NAME');

		selProj = CreateCustomProject(strProjectName, strProjectPath);
		AddConfig(selProj, strProjectName);
		AddFilters(selProj);

		var InfFile = CreateCustomInfFile();
		// Now we want to add the appropriate files to the project
		// based on the user's selections in the HTML UI.
		// See templates.inf file for the wizard directives which control
		// which files must be added to the project based on the user selections.
		AddFilesToCustomProj(selProj, strProjectName, strProjectPath, InfFile);
		PchSettings(selProj);
		InfFile.Delete();
		
		selProj.Object.Save();
	}
	catch(e)
	{
		if (e.description.length != 0)
			SetErrorInfo(e);
		return e.number
	}
}

function CreateCustomProject(strProjectName, strProjectPath)
{
	try
	{
		var strProjTemplatePath = wizard.FindSymbol('PROJECT_TEMPLATE_PATH');
		var strProjTemplate = '';
		strProjTemplate = strProjTemplatePath + '\\default.vcxproj';

		var Solution = dte.Solution;
		var strSolutionName = "";
		if (wizard.FindSymbol("CLOSE_SOLUTION"))
		{
			Solution.Close();
			strSolutionName = wizard.FindSymbol("VS_SOLUTION_NAME");
			if (strSolutionName.length)
			{
				var strSolutionPath = strProjectPath.substr(0, strProjectPath.length - strProjectName.length);
				Solution.Create(strSolutionPath, strSolutionName);
			}
		}

		var strProjectNameWithExt = '';
		strProjectNameWithExt = strProjectName + '.vcxproj';

		var oTarget = wizard.FindSymbol("TARGET");
		var prj;
		if (wizard.FindSymbol("WIZARD_TYPE") == vsWizardAddSubProject)  // vsWizardAddSubProject
		{
			var prjItem = oTarget.AddFromTemplate(strProjTemplate, strProjectNameWithExt);
			prj = prjItem.SubProject;
		}
		else
		{
			prj = oTarget.AddFromTemplate(strProjTemplate, strProjectPath, strProjectNameWithExt);
		}
		return prj;
	}
	catch(e)
	{
		throw e;
	}
}

function AddFilters(proj)
{
	try
	{
		// Add the folders to your project
		var group = proj.Object.AddFilter('Source Files');
		group.Filter = "cpp";
		var group2 = proj.Object.AddFilter('Header Files');
		group2.Filter = "h";		
		var group3 = proj.Object.AddFilter('Miscellaneous Files');
		group3.Filter = "txt";				
	}
	catch(e)
	{
		throw e;
	}
}

function AddConfig(proj, strProjectName)
{
	try
	{
		// Get required values from textboxes and checkboxes from
		// the HTML Ui. These values reflect the user's selections.
		//
		var maya70 = wizard.FindSymbol('Check_Maya_70');
		var maya80 = wizard.FindSymbol('Check_Maya_80');
		var maya85 = wizard.FindSymbol('Check_Maya_85');
		var maya2008 = wizard.FindSymbol('Check_Maya_2008');
		var maya2009 = wizard.FindSymbol('Check_Maya_2009');
		var maya2010 = wizard.FindSymbol('Check_Maya_2010');
		var maya2011 = wizard.FindSymbol('Check_Maya_2011');
    	var maya2012 = wizard.FindSymbol('Check_Maya_2012');
		
//		var strMayaLocation = wizard.FindSymbol('MAYA_LOCATION');
		var strCommandName = wizard.FindSymbol('MAYA_TYPE_NAME');
		var strAdditionalDependencies = "";
		
		// add debug and release configs for maya 70
		if ( maya70 )
			AddIndividualConfig(proj,strProjectName,'70','C:\\Program Files (x86)\\Alias\\Maya7.0');

		if ( maya80 )
			AddIndividualConfig(proj,strProjectName,'80','C:\\Program Files (x86)\\Alias\\Maya8.0');

		if ( maya85 )
			AddIndividualConfig(proj,strProjectName,'85','C:\\Program Files\\Autodesk\\Maya8.5');

		if ( maya2008 )
			AddIndividualConfig(proj,strProjectName,'2008','C:\\Program Files\\Autodesk\\Maya2008');
			
		if ( maya2009 )
			AddIndividualConfig(proj,strProjectName,'2009','C:\\Program Files\\Autodesk\\Maya2009');			
			
		if ( maya2010 )
			AddIndividualConfig(proj,strProjectName,'2010','C:\\Program Files\\Autodesk\\Maya2010');			
			
		if ( maya2011 )
			AddIndividualConfig(proj,strProjectName,'2011','C:\\Program Files\\Autodesk\\Maya2011');
        
        if ( maya2012 )
			AddIndividualConfig(proj,strProjectName,'2012','C:\\Program Files\\Autodesk\\Maya2011');
		
		if ( !maya70 && !maya80 && !maya85 && !maya2008 && !maya2009 && !maya2010 && !maya2011 && !maya2012)
			AddIndividualConfig(proj,strProjectName,'2012','C:\\Program Files\\Autodesk\\Maya2012');
		
		// doesn't works for now... will be fixed in next release (gromit)
		proj.Object.RemoveConfiguration( proj.Object.Configurations('Debug') );
		proj.Object.RemoveConfiguration( proj.Object.Configurations('Release') );
		
	}
	catch(e)
	{
		throw e;
	}
}




function AddIndividualConfig(proj, strProjectName, releaseNumber, strMayaLocation)
{
	// Now setup the compiler and linker settings for Debug
	//
	
	var wantFoundationLib = wizard.FindSymbol('Check_Foundation');
	var wantOpenMayaLib = wizard.FindSymbol('Check_OpenMaya');
	var wantOpenMayaUILib = wizard.FindSymbol('Check_OpenMayaUI');
	var wantOpenMayaAnimLib = wizard.FindSymbol('Check_OpenMayaAnim');
	var wantOpenMayaFXLib = wizard.FindSymbol('Check_OpenMayaFX');
	var wantOpenMayaRenderLib = wizard.FindSymbol('Check_OpenMayaRender');
	var wantImageLib = wizard.FindSymbol('Check_Image');
	var wantlibMocapLib = wizard.FindSymbol('Check_libMocap');
	var wantlibMDtAPILib = wizard.FindSymbol('Check_libMDtAPI');
	var wantOpenGL32Lib = wizard.FindSymbol('Check_OpenGL32');

	var strCommandName = wizard.FindSymbol('MAYA_TYPE_NAME');
	var strAdditionalDependencies = "";
	
	proj.Object.AddConfiguration('Debug_'+releaseNumber);
	proj.Object.AddConfiguration('Release_'+releaseNumber);
	
	var config = proj.Object.Configurations('Debug_'+releaseNumber);

	config.IntermediateDirectory = ('$(ConfigurationName)');
	config.OutputDirectory = '$(ConfigurationName)';
	config.ConfigurationType = ConfigurationTypes.typeDynamicLibrary;
	 
	var debugSettings = config.DebugSettings;
	debugSettings.Command = strMayaLocation + '\\bin\\maya.exe';
	debugSettings.PDBPath = '$(ConfigurationName)'+'\\';
	
	// Compiler Settings
	var CLTool = config.Tools('VCCLCompilerTool');
	CLTool.AdditionalIncludeDirectories = strMayaLocation + '\\include';
	CLTool.PreprocessorDefinitions = 'WIN32,_DEBUG,_WINDOWS,_AFXDLL,_MBCS,NT_PLUGIN,REQUIRE_IOSTREAM,Bits64_';
	CLTool.WarningLevel = warningLevelOption.warningLevel_3;
	CLTool.PrecompiledHeaderFile = '$(ConfigurationName)'+'/' + strCommandName + '.pch';
	CLTool.Optimization = optimizeOption.optimizeDisabled;
	CLTool.RuntimeLibrary = runtimeLibraryOption.rtMultiThreadedDebugDLL;
	CLTool.AdditionalOptions = '/Gm /GR /GS /EHsc /Zi /I "." /D "WIN32" /D "_DEBUG" /RTC1 /c';
	
	//Foundation.lib
	//OpenMaya.lib
	//OpenMayaAnim.lib
	
	var pluginType = wizard.FindSymbol('PLUG_IN_TYPE');
	
	// Linker Settings
	var LinkTool = config.Tools('VCLinkerTool');
	if (wantFoundationLib)
		strAdditionalDependencies += 'Foundation.lib ';
	if (wantOpenMayaLib)
		strAdditionalDependencies += 'OpenMaya.lib ';
	if (wantOpenMayaUILib)
		strAdditionalDependencies += 'OpenMayaUI.lib ';
	if (wantOpenMayaAnimLib || pluginType == 4 )
		strAdditionalDependencies += 'OpenMayaAnim.lib ';
	if (wantOpenMayaFXLib)
		strAdditionalDependencies += 'OpenMayaFX.lib ';
	if (wantOpenMayaRenderLib)
		strAdditionalDependencies += 'OpenMayaRender.lib ';
	if (wantImageLib)
		strAdditionalDependencies += 'Image.lib ';
	if (wantlibMocapLib)
		strAdditionalDependencies += 'libMocap.lib ';
	if (wantlibMDtAPILib)
		strAdditionalDependencies += 'libMDtAPI.lib ';
	if (wantOpenGL32Lib)
		strAdditionalDependencies += 'OpenGL32.lib ';
	
	LinkTool.AdditionalDependencies = strAdditionalDependencies;
	LinkTool.AdditionalLibraryDirectories = strMayaLocation + '\\lib';
	LinkTool.OutputFile = '$(ConfigurationName)'+'\\' + strCommandName + '.mll';
	LinkTool.ImportLibrary = '$(ConfigurationName)'+'/' + strCommandName + '.lib';
	LinkTool.ProgramDatabaseFile = '$(ConfigurationName)'+'/' + strCommandName + '.pdb';
	LinkTool.AdditionalOptions = '/subsystem:windows /dll /incremental:yes /debug /export:initializePlugin /export:uninitializePlugin';
	
	if ( pluginType == 4 )
	{
		LinkTool.AdditionalOptions += ' /FORCE:MULTIPLE';
	}
	
	
	// Now set the Release options for Compiling and Linking
	//		
	config = proj.Object.Configurations('Release_'+releaseNumber);
	config.IntermediateDirectory = '$(ConfigurationName)';
	config.OutputDirectory = '$(ConfigurationName)';
	config.ConfigurationType = ConfigurationTypes.typeDynamicLibrary;
//	config.ConfigurationName = 'Release_'+releaseNumber;

	var CLTool = config.Tools('VCCLCompilerTool');
	CLTool.AdditionalIncludeDirectories = strMayaLocation + '\\include';
	CLTool.PreprocessorDefinitions = 'WIN32,NDEBUG,_WINDOWS,_AFXDLL,_MBCS,NT_PLUGIN,REQUIRE_IOSTREAM,Bits64_';
	CLTool.WarningLevel = warningLevelOption.warningLevel_3;
	CLTool.PrecompiledHeaderFile = '$(ConfigurationName)'+'/' + strCommandName + '.pch';
	CLTool.Optimization = optimizeOption.optimizeMaxSpeed;
	CLTool.RuntimeLibrary = runtimeLibraryOption.rtMultiThreadedDLL;
	CLTool.AdditionalOptions = '/GR /GS /EHsc /I "."  /c';
	
	
	var LinkTool = config.Tools('VCLinkerTool');
	LinkTool.AdditionalDependencies = strAdditionalDependencies;
	LinkTool.AdditionalLibraryDirectories = strMayaLocation + '\\lib';
	LinkTool.OutputFile = '$(ConfigurationName)'+'\\' + strCommandName + '.mll';
	LinkTool.ImportLibrary = '$(ConfigurationName)'+'/' + strCommandName + '.lib';			
	LinkTool.ProgramDatabaseFile = '$(ConfigurationName)'+'/' + strCommandName + '.pdb';		
	LinkTool.AdditionalOptions = '/subsystem:windows /incremental:no /export:initializePlugin /export:uninitializePlugin';
	if ( pluginType == 4 )
	{
		LinkTool.AdditionalOptions += ' /FORCE:MULTIPLE';
	}

}



function PchSettings(proj)
{
	// TODO: specify pch settings
}

function DelFile(fso, strWizTempFile)
{
	try
	{
		if (fso.FileExists(strWizTempFile))
		{
			var tmpFile = fso.GetFile(strWizTempFile);
			tmpFile.Delete();
		}
	}
	catch(e)
	{
		throw e;
	}
}

function CreateCustomInfFile()
{
	try
	{
		var fso, TemplatesFolder, TemplateFiles, strTemplate;
		fso = new ActiveXObject('Scripting.FileSystemObject');

		var TemporaryFolder = 2;
		var tfolder = fso.GetSpecialFolder(TemporaryFolder);
		var strTempFolder = tfolder.Drive + '\\' + tfolder.Name;

		var strWizTempFile = strTempFolder + "\\" + fso.GetTempName();

		var strTemplatePath = wizard.FindSymbol('TEMPLATES_PATH');
		var strInfFile = strTemplatePath + '\\Templates.inf';
		wizard.RenderTemplate(strInfFile, strWizTempFile);

		var WizTempFile = fso.GetFile(strWizTempFile);
		return WizTempFile;
	}
	catch(e)
	{
		throw e;
	}
}

function GetTargetName(strName, strProjectName)
{
	try
	{
		// TODO: set the name of the rendered file based on the template filename
		var strTarget = strName;
		var pluginName = wizard.FindSymbol('MAYA_TYPE_NAME');

		if (strName == 'readme.txt')
			strTarget = 'ReadMe.txt';

		if (strName == 'sample.txt')
			strTarget = 'Options.txt';
			
		if (strName == 'emptyMain.cpp')
			strTarget = 'pluginMain.cpp';
			
		if (strName == 'simpleCmd.cpp')
			strTarget = pluginName + 'Cmd.cpp';			
			
		if (strName == 'complexCmd.cpp')
			strTarget = pluginName + 'Cmd.cpp';	
			
		if (strName == 'complexCmd.h')
			strTarget = pluginName + 'Cmd.h';				

		if (strName == 'complexCmdMain.cpp')
			strTarget = 'pluginMain.cpp';

		if (strName == 'dgNode.cpp')
			strTarget = pluginName + 'Node.cpp';	
			
		if (strName == 'dgNode.h')
			strTarget = pluginName + 'Node.h';				

		if (strName == 'dgNodeMain.cpp')
			strTarget = 'pluginMain.cpp';
			
		if (strName == 'deformerNode.cpp')
			strTarget = pluginName + 'Node.cpp';
			
		if (strName == 'deformerNode.h')
			strTarget = pluginName + 'Node.h';
		
		if (strName == 'deformerMain.cpp')
			strTarget = 'pluginMain.cpp';
		
		return strTarget; 
	}
	catch(e)
	{
		throw e;
	}
}

function AddFilesToCustomProj(proj, strProjectName, strProjectPath, InfFile)
{
	try
	{
		var projItems = proj.ProjectItems

		var strTemplatePath = wizard.FindSymbol('TEMPLATES_PATH');

		var strTpl = '';
		var strName = '';

		var strTextStream = InfFile.OpenAsTextStream(1, -2);
		while (!strTextStream.AtEndOfStream)
		{
			strTpl = strTextStream.ReadLine();
			if (strTpl != '')
			{
				strName = strTpl;
				var strTarget = GetTargetName(strName, strProjectName);
				var strTemplate = strTemplatePath + '\\' + strTpl;
				var strFile = strProjectPath + '\\' + strTarget;

				var bCopyOnly = false;  //"true" will only copy the file from strTemplate to strTarget without rendering/adding to the project
				var strExt = strName.substr(strName.lastIndexOf("."));
				if(strExt==".bmp" || strExt==".ico" || strExt==".gif" || strExt==".rtf" || strExt==".css")
					bCopyOnly = true;
				wizard.RenderTemplate(strTemplate, strFile, bCopyOnly);
				proj.Object.AddFile(strFile);
			}
		}
		strTextStream.Close();
	}
	catch(e)
	{
		throw e;
	}
}
